package com.test.assignment.abstractexample;

abstract class Person {
	String name;
	int age;
	float height;
	float weight;
	
	Person(String name, int age, float height, float weight){
		super();
		this.name = name;
		this.age = age;
		this.height = height;
		this.weight = weight;
	}
	
	public abstract void dispalyDetails();
	
	// Abstract method
    public abstract void canRun();
    
    // Concrete method
    public void eat() {
        System.out.println(name + " is eating.");
    }
	
}
