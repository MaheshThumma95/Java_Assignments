package com.test.assignment.abstractexample;

public class Student extends Person{

	int rollno;
	int marks;
	
	Student(String name, int age, float height, float weight,int rollno,int marks) {
		super(name, age, height, weight);
		this.rollno = rollno;
		this.marks = marks;
	}

	
	@Override
	public void canRun() {
		// TODO Auto-generated method stub
		System.out.println(name+" can run");
	}
	

	@Override
	public void dispalyDetails() {
		System.out.println("Studnet name is   ::"+name);
		System.out.println("Studnet age is 	  ::"+age);
		System.out.println("Studnet height is ::"+height);
		System.out.println("Studnet weight is ::"+weight);
		System.out.println("Studnet rollno is ::"+rollno);
		System.out.println("Studnet marks are ::"+marks);
	}

}
