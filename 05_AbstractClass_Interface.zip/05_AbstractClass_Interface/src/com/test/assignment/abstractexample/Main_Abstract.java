package com.test.assignment.abstractexample;

import java.util.Scanner;


/*5. Demonstrate the difference between abstract class and interface by writing programs
as well as in keypoints.*/

public class Main_Abstract {

public static void main(String[] args) {
	
		//Take student input from the user
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter studnet name::");
		String name = scanner.nextLine();
		
		System.out.println("Enter studnet age::");
		int age  = scanner.nextInt();
		
		System.out.println("Enter studnet height::");
		float height  = scanner.nextFloat();
		
		System.out.println("Enter studnet weight::");
		float weight  = scanner.nextFloat();
		
		System.out.println("Enter studnet rollno::");
		int rollno = scanner.nextInt();
		
		System.out.println("Enter studnet marks::");
		int marks  = scanner.nextInt();
				
		
		Student student = new Student(name,age,height,weight,rollno,marks);
		System.out.println("====================================");
		System.out.println(" Display Student All Details		");
		System.out.println("====================================");
		
		student.dispalyDetails();
		student.canRun();
		student.eat();
		
	} 

}

/**
 * 
 * 
 * Abstact Class: 
-------------
abstract is keyword

The abstract keyword we can use in class level and method level, But we can't use for variables.

1)We can't create Object for Abstract Class.
2)abstarct class can have all methods abstract, that means 100% abstraction)
3)abstract class can have both abstract and concreate method
4)abstract class can have all methods, But we ca't create object
5)If anyone don't want to create object for your class. we can make our class as abstract.
6) if subclass/child class if extending abstract class then either have to implement abstract method or declare class as abstract.
7) constuctor can't be made abstract.
8) we can't make abstract class as final because final methods will not participate in inheritance  and it can't overriden in child class.
 * 
 * 
 * 
 */
