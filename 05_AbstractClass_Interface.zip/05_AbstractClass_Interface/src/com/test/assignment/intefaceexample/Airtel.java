package com.test.assignment.intefaceexample;

public class Airtel implements SIM {

	@Override
	public String dailCall(long mobilenumber) {
		
		return "Airtel: The number "+mobilenumber+" you are dailing currently busy, please dial after some time";
	}

	@Override
	public String sendSMS(String msg, long mobilenumber) {
		
		
		return "From Airtel, Your Message sent Successfully To::"+mobilenumber+"\nYour Message is ::"+msg;
	}

}
