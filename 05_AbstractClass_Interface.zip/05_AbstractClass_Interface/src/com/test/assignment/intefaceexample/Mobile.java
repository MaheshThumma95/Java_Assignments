package com.test.assignment.intefaceexample;

public class Mobile {

	private SIM sim;
	
	public void insertSIM(SIM simName) { 	
		sim = simName;		
	}
	 
	public String dialCall(long mobileNumber) {
		return sim.dailCall(mobileNumber);
	}
	 
	public String sendSMS(String  msg, long mobileNumber) {
		return sim.sendSMS(msg, mobileNumber);
	}
	
	
}
