package com.test.assignment.intefaceexample;

public interface SIM {
	public String dailCall(long mobilenumber);
	public String sendSMS(String msg, long mobilenumber);
}
