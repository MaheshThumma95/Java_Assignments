package com.test.assignment.intefaceexample;

public class Jio implements SIM {

	@Override
	public String dailCall(long mobilenumber) {
		
		return "Jio: The number "+mobilenumber+" you are dailing is not reachable, please dial after some time";
	}

	@Override
	public String sendSMS(String msg, long mobilenumber) {
		// TODO Auto-generated method stub
		
		return "From Jio, Your Message sent Successfully To::"+mobilenumber+"\nYour Message is ::"+msg;
	}





}
