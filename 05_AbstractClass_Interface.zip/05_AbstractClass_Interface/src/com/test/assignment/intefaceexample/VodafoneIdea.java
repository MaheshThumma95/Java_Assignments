package com.test.assignment.intefaceexample;

public class VodafoneIdea implements SIM {

	@Override
	public String dailCall(long mobilenumber) {
	
		return "VodafoneIdea: The number "+mobilenumber+" you are dailing is switched off, please dial after some time";		
	}

	@Override
	public String sendSMS(String msg, long mobilenumber) {

		return "From VodafoneIdea, Your Message sent Successfully To::"+mobilenumber+"\nYour Message is ::"+msg;
	}




}
