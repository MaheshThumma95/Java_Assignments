package com.test.assignment.intefaceexample;

import java.util.InputMismatchException;
import java.util.Scanner;


/*5. Demonstrate the difference between abstract class and interface by writing programs
as well as in keypoints.*/

public class Main_Inteface_Test {

	public static void main(String[] args) throws Exception {

		long mobilenumber;
		String msg=null;
		Mobile samsungMobile;
		boolean availableSIM = false;
		
		// Take input from the user
		Scanner scanner = new Scanner(System.in);
		
		samsungMobile = new Mobile();
		while (true) {
		System.out.println();	
		System.out.println("===========================================================");
		System.out.println("Choose any one option to insert in the SIM in mobile::");
		System.out.println("===========================================================");
		System.out.println("1. Airtel");
		System.out.println("2. Jio");
		System.out.println("3. Vodafone Idea");
		System.out.println("4. Exit");

		int selectedSIM = scanner.nextInt();

		if (selectedSIM == 1) {
			Airtel airtel = new Airtel();
			samsungMobile.insertSIM(airtel);
			availableSIM = true;
			System.out.println("Airtel SIM Inserted");
		} else if (selectedSIM == 2) {
			Jio jio = new Jio();
			samsungMobile.insertSIM(jio);
			availableSIM = true;
			System.out.println("Jio SIM Inserted");
		} else if (selectedSIM == 3) {
			VodafoneIdea vi = new VodafoneIdea();
			samsungMobile.insertSIM(vi);
			availableSIM = true;
			System.out.println("Vodafone Idea SIM Inserted");
		}else if (selectedSIM == 4) {
			System.out.println("------------------------------------------------------------------------");
			System.out.println("Exiting! Thanks for using our services!");
			System.exit(0);
		}
		else {
			System.out.println("Please select valid input");
		}

			if (availableSIM) { // if sim card available process below logic
				System.out.println("==================================");
				System.out.println("Choose any option what you want to do?");
				System.out.println("==================================");
				System.out.println("1. Dail Call?");
				System.out.println("2. Send SMS");
				System.out.println("3. Exit");

				int choice = scanner.nextInt();

				switch (choice) {
				case 1:
					System.out.println("Enter MOBILE NUMBER whom you want to call?");
					mobilenumber = scanner.nextLong();

					try {
			        	  if (mobilenumber < 0) {
			                  throw new IllegalArgumentException("The mobile should not have negative number");
			              }
			        System.out.println("----------------------------------OUTPUT-------------------------------");
					System.out.println("Dail:" + samsungMobile.dialCall(mobilenumber));
					System.out.println("------------------------------------------------------------------------");
			            
					} catch (IllegalArgumentException e) {
			            System.out.println("Invalid Number, Please try again! " + e.getMessage());
			        }
					catch (Exception e) {
				            System.out.println("Invalid Number, Please try again! " + e.getMessage());
				    }
					break;

				case 2:
					System.out.println("Enter MOBILE NUMBER whom you want to send Message?");
					mobilenumber = scanner.nextLong();
					
					// Skip the newline
					  scanner.nextLine();
					  
					System.out.println("Enter MESSAGE what you want to text:");
					msg = scanner.nextLine();
					System.out.println("----------------------------------OUTPUT-------------------------------");
					System.out.println("SMS ::" + samsungMobile.sendSMS(msg, mobilenumber));
					System.out.println("------------------------------------------------------------------------");
					break;

				case 3:
					System.out.println("------------------------------------------------------------------------");
					System.out.println("Exiting! Thanks for using our services!");
					System.exit(0);
					break;
				}

			} else {
				System.out.println("Invalid SIM (or) SIM not inserted");
			}
		} // loop end

	} // main end
}


/*
 * 
 * 
 * Difference between Abstract class an Interface:
===================================================

Interface: If we don't know anything about implementation just we have requirement specification then we should go for interface.
Abstract class: If we are taking about implementation but not completly then we should go for abstract.

Interface: Every method present inside the interface is always public and abstract whether we are declaring or not.
Abstract class: Every method present inside abstract class need not be public and abstract.


Interface: We can't declare  interface methods, with the modifiers like private, protected, final, static, synchronized, native, strictfp.
Abstract class: There are no restrictions on abstract class method modifiers.

Interface: Every interface variable is always public static final whether we are declaring or not.
Abstract class: Every abstract class variable need not be public static final.

Interface: For every interface variable compulsorily we should perform initilization at the time of declaration, otherwise we will get compile time error.
Abstract class: Not Required to perform initialization  for abstract class variables at the time of declaration.

Interface:: Inside inteface we can't write and instance block.
Abstract class: Inside abstract class we can write static and instance block.

Inteface: Inside interface we can't write constuctor.
Abstract: Inside interface we can write constructor.

abstract class Object we can't create because it is abstract.
But constructor is need for constructor to initialize the object
 * 
 * 
 * 
 * 
 */
