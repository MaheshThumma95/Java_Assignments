package com.test.assignment;

import java.util.Arrays;
import java.util.Scanner;

/*
 * 7. Create a Java program that implements a binary search algorithm. The program
should accept user input for the target value and search for it in a sorted array. The
program should return the index of the target value if found or a message if not
found.
 * 
 */
public class BinarySearch {

	public static void main(String[] args) {
		
		try {
			 Scanner scanner = new Scanner(System.in);

		        // take the input from the user to enter the target value
		        System.out.println("Enter the target value: ");
		        int target = scanner.nextInt();

		        
		        /////////////////////////
		        // take the input from the user to enter the number of elements in the array or (size of an array)
		        System.out.println("Enter the number of elements in the array or [size of an array]: ");
		        int n = scanner.nextInt();

		        // Create an array with the user specified size
		        int[] numbers = new int[n];

		        
		        
		        //prompt the user to enter the elements of the array
		        for (int i = 0; i < n; i++) {
		            System.out.println("Enter the element at index " + i + ": ");
		            numbers[i] = scanner.nextInt();
		        }

		        // Print the array
		        System.out.println("The given array elements are before sort: ");
		        for (int i = 0; i < n; i++) {
		            System.out.print(numbers[i] + " ");
		        }
		        
		        // Sort the array
		        Arrays.sort(numbers);
		        
		        System.out.println();
		        System.out.println("The given array elements are after sort: ");
		        for (int i = 0; i < n; i++) {
		            System.out.print(numbers[i] + " ");
		        }
		              
		        // Find the index of the target value in the array
		        int index = binarySearch(numbers, target);

		        // If the target value is found, print its index
		        if (index != -1) {
		            System.out.println("\n The target value is found at index " + index);
		        } else {
		            System.out.println("\n The target value is not found");
		        }
	

		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}

	}

	 public static int binarySearch(int[] array, int target) {
	        
	        int low = 0;
	        int high = array.length - 1;

	        
	        while (low <= high) {
	            // find the middle index
	            int mid = (low + high) / 2;

	            // If the given target value is !=  the middle element, return the index
	            if (target == array[mid]) {
	                return mid;
	            } else if (target < array[mid]) {
	                // If the target value is less than the middle element
	            	//and  set the high index to the middle index - 1
	                high = mid - 1;
	            } else {
	                // If the target value is greater than the middle element, set the low index to the middle index + 1
	                low = mid + 1;
	            }
	        }

	        //If the target value is not found return -1 
	        return -1;
	 }
	
}
/*
 * Output- 1:
 * 
Enter the target value: 
5
Enter the number of elements in the array or [size of an array]: 
8
Enter the element at index 0: 
10
Enter the element at index 1: 
4
Enter the element at index 2: 
6
Enter the element at index 3: 
60
Enter the element at index 4: 
86
Enter the element at index 5: 
5
Enter the element at index 6: 
37
Enter the element at index 7: 
92
The given array elements are before sort: 
10 4 6 60 86 5 37 92 
The given array elements are after sort: 
4 5 6 10 37 60 86 92 
 The target value is found at index 1
 --------------------------------------------------
 
 
 Output- 2:
 
 
 Enter the target value: 

4
Enter the number of elements in the array or [size of an array]: 

6
Enter the element at index 0: 
10
Enter the element at index 1: 
39
Enter the element at index 2: 
46
Enter the element at index 3: 
33
Enter the element at index 4: 
66
Enter the element at index 5: 
86
The given array elements are before sort: 
10 39 46 33 66 86 
The given array elements are after sort: 
10 33 39 46 66 86 
 The target value is not found
*/
