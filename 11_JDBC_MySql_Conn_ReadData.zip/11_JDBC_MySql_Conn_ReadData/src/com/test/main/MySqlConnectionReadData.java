package com.test.main;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.test.util.JDBCUtils;

/*
 * 11. Write a Java program that connects to a MySQL database using JDBC. The program
	   should read data from a table and display the results in the console.
 * 
 */
public class MySqlConnectionReadData {

	public static void main(String[] args) {
		
	
	Connection connection = null;
	Statement statement   = null;
	ResultSet resultSet	  = null;
	
	
	try {
		// Step-2. Establish the Connection
		connection = JDBCUtils.getConnection();
		
		if(connection!=null) {
			// Step-3. Create statement Object and send the Query
			statement = connection.createStatement();
			
			if(statement!=null) {
				System.out.println("Statement Object created successfully!");
				System.out.println();
				// step-4: Execute the query and process the resultSet
				String sqlSelectQuery = "SELECT sid,sname,sage,saddress FROM STUDENT";
				resultSet = statement.executeQuery(sqlSelectQuery);
				System.out.println("--------------------------------------------");
				System.out.println("SID \t SNAME \t   SAGE \tSADDRESS");
				System.out.println("--------------------------------------------");
				
				
				  // Process the results
	            if (!resultSet.next()) {
	                System.out.println("The result set is empty. Please add some records.");
	            } else {
	                do {
	                	// Display the data
						System.out.printf("%2d%12s%9d%13s",resultSet.getInt(1),resultSet.getString(2),resultSet.getInt(3),resultSet.getString(4));	
						System.out.println();
	                } while (resultSet.next());
	            } 
			}	
		}	
		
	}catch(IOException ex) { 
		ex.printStackTrace();
	}
	catch(SQLException se) { // Step-5. Handle the SQLException if it gets generated.
		se.printStackTrace();
	}
	catch(Exception e) {
		e.printStackTrace();
	}finally {
		try {
			JDBCUtils.cleanUp(connection, statement, resultSet);
			System.out.println("--------------------------------------------");
			System.out.println();
			System.out.println("Closing the resources!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}	
 }
}

/*
 *Output:
 *----------
Connection Object is created successfully!
Statement Object created successfully!

--------------------------------------------
SID 	 SNAME 	   SAGE 	SADDRESS
--------------------------------------------
 1      Mahesh       28          Hyd
 2      Ramesh       29     Gujarath
 3      Harish       25       Mumbai
 4     Chandra       30        Delhi
 5    Santhosh       32     Santhosh
--------------------------------------------

Closing the resources!

 * 
 */
