package com.test.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class JDBCUtils {
	
	public static Connection getConnection()throws SQLException, IOException{
		//take the data from the properties file
		FileInputStream fis = new FileInputStream("D:\\Mahesh\\Special\\EWS\\_Assignments\\11_JDBC_MySql_Conn_ReadData\\src\\application.properties");
		//FileInputStream fis = new FileInputStream("D:\\Mahesh\\Special\\EWS\\_Assignments\\11_JDBC_MySql_Conn_ReadData\\src\\application.properties");
		Properties properties = new Properties();
		properties.load(fis);
		//Step:1. Load and register the Driver.
		Connection connection = DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("user"),properties.getProperty("password"));
		System.out.println("Connection Object is created successfully!");
		return connection;
	}
	
	
	public static void cleanUp(Connection conn, Statement statement, ResultSet resultSet) throws SQLException{
		if(conn!=null) {
			conn.close();
		}
		if(statement!=null) {
			statement.close();
		}
		if(resultSet!=null) {
			resultSet.close();
		}
	}
}
