package com.test.assignment;

import java.util.Scanner;

/*
 * 4. Create a Java program that simulates a bank account. The program should allow
	users to deposit and withdraw money, check their balance.
 * 
 */

public class BankAccount {
	
	private String accountNumber;
	private String name;
	private long  balance;
	
	//constructor
	public BankAccount(String accountNumber, String name, long balance) {
		super();
		this.accountNumber = accountNumber;
		this.name = name;
		this.balance = balance;
	}
	
	//Getters and Setters 
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	
	public void withdraw(long amount) {
		this.balance = balance - amount;
	}

	public void deposit(long amount) {
		//this.balance += amount;
		this.balance = balance+ amount;
	}

}
