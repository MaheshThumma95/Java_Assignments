package com.test.assignment;

import java.util.Scanner;

public class Main {

public static void main(String[] args) {
		
		//Take input from the user
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter your bank account number::");
		String accountNumber = scanner.nextLine();
		
		System.out.println("Enter your name::");
		String bankName = scanner.nextLine();
		
		System.out.println("Enter your inital balance:");
		long balance = scanner.nextLong();
		
		BankAccount bankAccount = new BankAccount(accountNumber,bankName,balance);
		
		while(true) {
			System.out.println("==================================");
			System.out.println("Options are available:");
			System.out.println("==================================");
			System.out.println("1. Deposit Money");
			System.out.println("2. Cash Withdraw");
			System.out.println("3. Balance Enquiry");
			System.out.println("4. Exit");
			
			int choice = scanner.nextInt();
			
			switch(choice) {
			case 1:
				System.out.println("Enter the amount you want to deposit::");
				long amount = scanner.nextLong();
	
				bankAccount.deposit(amount);
				System.out.println("------------------------------------------------------------------------");
				System.out.println("Your current available balance after deposit::"+bankAccount.getBalance());
				System.out.println("------------------------------------------------------------------------");
				break;
				
			case 2:
				System.out.println("Enter the amount you want to withdraw::");
				amount = scanner.nextLong();
				try {
					 if (amount < 0) {
		                  throw new IllegalArgumentException("Invalid Input,Please Try Again!");
		              }
					 //System.out.println("check logic::: "+amount+"<"+bankAccount.getBalance());
					 if(amount<balance) {
						 	bankAccount.withdraw(amount);
							System.out.println("------------------------------------------------------------------------");
							System.out.println("Your current available balance after withdraw::"+bankAccount.getBalance());					
							System.out.println("------------------------------------------------------------------------");	 
					 }else {
							System.out.println("Your can't withdraw, Insufficient Balance::"+bankAccount.getBalance());
					 }
											 
					 						 
					
				}catch(IllegalArgumentException e) {
					System.out.println(e.getMessage());
				}				
				break;
				
			case 3:
				System.out.println("------------------------------------------------------------------------");
				System.out.println("Your balance is ::"+bankAccount.getBalance());
				System.out.println("------------------------------------------------------------------------");
				break;
				
			case 4:
				System.out.println("------------------------------------------------------------------------");
				System.out.println("Exiting! Thanks for using our services!");
				System.exit(0);
				break;
			}				
			
		}//loop end
			
	} //main end

}
