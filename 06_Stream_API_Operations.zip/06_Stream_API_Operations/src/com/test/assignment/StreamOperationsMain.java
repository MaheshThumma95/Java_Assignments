package com.test.assignment;

/*
 * 6. Write a Java program that uses stream api to perform operations on a large data set,
	  such as sorting or filtering the data.	  
*
*/

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

class Employee {
	private String name;
	private int age;

	public Employee() {

	}

	public Employee(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", age=" + age + "]";
	}

}

public class StreamOperationsMain {

	public static void main(String[] args) {
		try {
			
			// created list of Person objects
			List<Employee> emp = new ArrayList<>();
			emp.add(new Employee("Mahesh", 28));
			emp.add(new Employee("Harish", 26));
			emp.add(new Employee("Chandra", 18));
			emp.add(new Employee("Aravind", 38));
			emp.add(new Employee("Anil", 26));
			emp.add(new Employee("Kumar", 65));
			emp.add(new Employee("Balraj", 39));
			emp.add(new Employee("Laxman", 49));
			emp.add(new Employee("Ram", 55));
			emp.add(new Employee("Narasimha", 53));
			emp.add(new Employee("Narasimha", 89));
			
			
			
			// Sorting the data using stream API
			System.out.println("Sorted the given list of employees data by name");
			System.out.println("-------------------------------------------");
			List<Employee> sortedPeople = emp.stream()
					.sorted((employee1, employee2) -> employee1.getName().compareTo(employee2.getName()))
					.collect(Collectors.toList());

			// System.out.println("Sorted people (by name): " + sortedPeople);
			sortedPeople.forEach(System.out::println);

			System.out.println();
			
			Scanner scanner = new Scanner(System.in);
			System.out.println("************ Please Enter Employee Age to Filter the Data *************");
			int targetAge = scanner.nextInt();
			
			
			if (targetAge < 0) {
				throw new IllegalArgumentException("Invalid Age, Please enter valid age");
			}

	        // Filtering the data using stream API
	        List<Employee> filteredPeople = emp.stream()
	                .filter(person -> person.getAge() >= targetAge)
	                .collect(Collectors.toList());

	        boolean ageNotFound = filteredPeople.stream()
	                .noneMatch(employee -> employee.getAge() >= targetAge);

	        if (ageNotFound) {
	            System.out.println("No person found with age " + targetAge);
	        } else {
				System.out.println("=============================================================");
				System.out.println("Filtered employees data who's age >=" + targetAge + "::");
				System.out.println("=============================================================");
				filteredPeople.forEach(System.out::println);
	        }
		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}

	}

}

/*
 * 
 * 
Output:
---------- 

Sorted the given list of employees data by name
-------------------------------------------
Employee [name=Anil, age=26]
Employee [name=Aravind, age=38]
Employee [name=Balraj, age=39]
Employee [name=Chandra, age=18]
Employee [name=Harish, age=26]
Employee [name=Kumar, age=65]
Employee [name=Laxman, age=49]
Employee [name=Mahesh, age=28]
Employee [name=Narasimha, age=53]
Employee [name=Narasimha, age=89]
Employee [name=Ram, age=55]

************ Please Enter Employee Age to Filter the Data *************
40
=============================================================
Filtered employees data who's age >=40::
=============================================================
Employee [name=Kumar, age=65]
Employee [name=Laxman, age=49]
Employee [name=Ram, age=55]
Employee [name=Narasimha, age=53]
Employee [name=Narasimha, age=89]


*/