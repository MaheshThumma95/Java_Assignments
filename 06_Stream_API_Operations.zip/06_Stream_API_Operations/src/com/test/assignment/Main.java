package com.test.assignment;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/*
 * 6. Write a Java program that uses stream api to perform operations on a large data set,
	  such as sorting or filtering the data.	  
*
*/


public class Main {


    public static void main(String[] args) {    	
    	
    	List<Integer> numbers = Arrays.asList(41,94,3,14,5,36,74,86,9);
    	
    	//we need to sort the ascending order the given array
    	System.out.println("The Given Array Elements are Sorted");
    	List<Integer> sortedNumbers = numbers.stream().sorted().collect(Collectors.toList());
    	
    	//print the sorted list
    	System.out.println(sortedNumbers);
    	
    	System.out.println();
    	
    	//Filter the list to only even numbers
    	System.out.println("Print Only Even Numbers");
    	List<Integer> evenNums = numbers.stream().filter(number->number%2 == 0).collect(Collectors.toList());
    	
    	//Print the filtered list
    	System.out.println(evenNums);
    }

}
/*OUTPUT: 

The Given Array Elements are Sorted
[3, 5, 9, 14, 36, 41, 74, 86, 94]

Print Only Even Numbers
[94, 14, 36, 74, 86]

*/