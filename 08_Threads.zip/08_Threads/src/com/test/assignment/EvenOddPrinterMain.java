package com.test.assignment;

/*
 * 8.Write a Java program that creates two threads. The first thread should print even
numbers between 1 and 10, and the second thread should print odd numbers
between 1 and 10.
 * 
 */
class EvenNumPrinter implements Runnable{

	@Override
	public void run() {
		
		for (int i = 2; i <= 10; i += 2) {
            System.out.println("even:: " + i);
        }
		
	}
	
	
}

class OddNumPrinter implements Runnable{

	@Override
	public void run() {
		
		 for (int i = 1; i <= 9; i += 2) {
	            System.out.println("odd:: " + i);
	     }
	}
	
}

public class EvenOddPrinterMain {

	public static void main(String[] args) {
		
		Thread evenThread  = new Thread(new EvenNumPrinter());
		Thread oddThread  = new Thread(new  OddNumPrinter());
		
		evenThread.start();
		oddThread.start();
		
	}

}

/*
 * Output:
 *  
odd:: 1
even:: 2
odd:: 3
even:: 4
odd:: 5
odd:: 7
odd:: 9
even:: 6
even:: 8
even:: 10
 * 
 * */
