package com.test.assignment;

public class Parent {
	
	Parent(){
		System.out.println("Parent class constructor called");
	}
}
