package com.test.assignment;

public class Child extends Parent{

	Child(){
		System.out.println("Child class constructor called");
	}
		
}
