package com.test.assignment;

/*
 * 2. Write a Java program to invoke parent class constructor from a child class. Create
	Child class object and parent class constructor must be invoked. Demonstrate by
	writing a program. Also explain key points about Constructor.
*/

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child child = new Child();

	}

}

/* Some few key points about constructor: 
 * ---------------------------------------
 * A name of Constructor mus be the same as the name of the class 
 * 
 * A Constructor don't have a retrun type.
 * 
 * Constructors are automatically called when an object of a class is created with the help of 'new' keyword.
 * 
 * A constructor can be used to initalize the state of the Object.
 * 
 * A constructor can be overloaded, which means that it can have multiple signatures.
 * 
 * If a class extends another class, the child class constructor must invoke the constructor of the parent class before executing it's own cod. 
 * This is achieved using the 'super()' statement, which calls the parent calss constructor
 *  
 * A constructor can't be called directly. It is called implicity when an object created.
 * 
 * If a class does not have a constructor, the compiler will create a default constructor for it.
 * 
 * A Constructor can't overridden
 * 
 * A Consructor can't be static
 * 
 * Constructors can have acess modifiers (eg: public, private, protected) to control thier visibility
 * 
 * 
 * 
 * */


