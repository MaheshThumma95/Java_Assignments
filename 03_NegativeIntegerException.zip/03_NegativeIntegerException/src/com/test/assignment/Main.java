package com.test.assignment;

import java.util.Scanner;

/*
 * 3. Write a Java programme that takes an integer from the user and throws an exception
	if it is negative.Demonstrate Exception handling of same program as solution.
 *
 * */

public class Main {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter an integer: ");
        int number = scanner.nextInt();

        try {
        	  if (number < 0) {
                  throw new IllegalArgumentException("The given number is Negative");
              }

            System.out.println("The given number is positive.");
        } catch (IllegalArgumentException e) {
            System.out.println("Exception caught:: " + e.getMessage());
        }
    }

}
