package com.test.assignment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class SecondLargestAndSmallest {
    public static void main(String[] args) {
    	
    	Scanner scanner = new Scanner(System.in);
    	List<Integer> numbers = new ArrayList<>();
    	System.out.println("Enter the number of integers you want to enter?");
    	int count = scanner.nextInt();
    	
    	System.out.println("Enter the integers::");
    	for(int i=0;i<count;i++) {
    		numbers.add(scanner.nextInt());
    	}
    	
    	
    	if(numbers.size() < 2){
    		System.out.println("Please enter atleast two integers");
    		return;
    	}
    	
    	System.out.println("The given elements are::");
    	System.out.println(numbers);
    	
    	System.out.println();
    	
    	System.out.println("Sort the given elements are::");
    	Collections.sort(numbers);
    	System.out.println(numbers);
    	
    	System.out.println();
    	
    	int secondSmallest = findSecondSmallest(numbers);
    	int secondLargest = findSecondLargest(numbers);    	
    	
    	System.out.println("Second smallest element::"+secondSmallest);
    	System.out.println("Second largest  element::"+secondLargest);
    	
    }
    
    private static int findSecondLargest(List<Integer> numbers) {
		Collections.sort(numbers);
		return numbers.get(numbers.size()-2);
	}

	public static int findSecondSmallest(List<Integer> numbers) {
    	Collections.sort(numbers);
    	return numbers.get(1);
    }
}
