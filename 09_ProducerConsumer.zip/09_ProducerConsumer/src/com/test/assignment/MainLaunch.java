package com.test.assignment;

/*
 * 9.Write a Java program that implements a producer-consumer model using
multithreading. The program should have a producer thread that generates random
numbers and adds them to a queue, and a consumer thread that reads numbers
from the queue and calculates their sum. The program should use synchronization to
ensure that the queue is accessed by only one thread at a time.*/

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

class ProducerConsumer {
    private static final int QUEUE_CAPACITY = 10;
    private Queue<Integer> queue = new LinkedList<>();
    
    public void start() {
        Thread producerThread = new Thread(new Producer());
        Thread consumerThread = new Thread(new Consumer());
        
        producerThread.start();
        consumerThread.start();
        
        try {
            producerThread.join();
            consumerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    class Producer implements Runnable {
        private Random random = new Random();
        
        public void run() {
            while (true) {
                synchronized (queue) {
                    while (queue.size() >= QUEUE_CAPACITY) {
                        try {
                            queue.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    
                    int number = random.nextInt(100);
                    queue.add(number);
                    System.out.println("Produced: " + number);
                    
                    queue.notifyAll();
                }
                
                try {
                	 //before producing the next number
                    Thread.sleep(1000); // Sleep for 1 second
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    class Consumer implements Runnable {
        public void run() {
            while (true) {
                synchronized (queue) {
                    while (queue.isEmpty()) {
                        try {
                            queue.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    
                    int sum = 0;
                    while (!queue.isEmpty()) {
                        int number = queue.poll();
                        sum += number;
                        System.out.println("Consumed: " + number);
                    }
                    System.out.println("Sum: " + sum);
                    
                    queue.notifyAll();
                }
                
                try {
                	//before consuming the next numbers
                    Thread.sleep(2000);  //2 seconds
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

public class MainLaunch {
    public static void main(String[] args) {
        ProducerConsumer pc = new ProducerConsumer();
        pc.start();
    }
}


/*
 * Output:
 * -------
 * 
Produced: 8
Consumed: 8
Sum: 8
Produced: 21
Consumed: 21
Sum: 21
Produced: 33
Produced: 47
Consumed: 33
Consumed: 47
Sum: 80
Produced: 16
Produced: 11
Consumed: 16
Consumed: 11
Sum: 27
Produced: 30
Produced: 29
Consumed: 30
Consumed: 29
Sum: 59
 * 
 * 
 */