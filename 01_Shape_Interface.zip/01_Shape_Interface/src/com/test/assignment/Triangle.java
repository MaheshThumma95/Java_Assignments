package com.test.assignment;

import java.util.Scanner;

public class Triangle implements Shape {
	
	private double base;
	private double height;
	
	
	public Triangle() {
		
	}

	public Triangle(double base, double height) {
		this.base = base;
		this.height = height;
	}
	

	@Override
	public double getArea() {
		
		return (base * height)/2;
	}

	@Override
	public double getPerimeter() {
		
		//return base + 2 * height;
		return base + height + Math.sqrt(base * base + height * height);
	}

	@Override
	public void input() {
		Scanner scan = new Scanner(System.in);
		System.out.println("\nPlease enter the base of triangle:");
		double base = scan .nextDouble();
		
		System.out.println("Please enter the height of triangle:");
		double height =scan.nextDouble();	
		
		Shape t = new Triangle(base,height);
		System.out.println("The area of the triangle is " + t.getArea());
	    System.out.println("The perimeter of the triangle is " + t.getPerimeter());	
	}

}
