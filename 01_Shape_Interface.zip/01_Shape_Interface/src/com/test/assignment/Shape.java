package com.test.assignment;

public interface Shape {
	
	  void input();
	  double getArea();
	  double getPerimeter();
}
