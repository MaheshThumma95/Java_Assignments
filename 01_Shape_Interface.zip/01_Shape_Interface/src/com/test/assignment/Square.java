package com.test.assignment;

import java.util.Scanner;

public class Square implements Shape {

	private double length;
	
	public Square() {
		
	}
	
	public Square(double length) {
		this.length = length;
	}



	@Override
	public double getArea() {
	
		return length * length;
	}


	@Override
	public double getPerimeter() {
		
		return 4*length;
	}


	@Override
	public void input() {
		Scanner scan = new Scanner(System.in);
		System.out.println("\nPlease enter the legnth of square");
		double len = scan.nextDouble();
		
		Shape sq = new Square(len);
		System.out.println("The area of the square is " + sq.getArea());
		System.out.println("The perimeter of the square is " + sq.getPerimeter());
		
	}

}
