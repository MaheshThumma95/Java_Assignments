package com.test.assignment;

public class Geometry {
	
/*	void permit(Shapes s)
	{
		s.input();
		s.compute();
		s.disp();
	}*/
}
