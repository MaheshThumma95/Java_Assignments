package com.test.assignment;

import java.util.Scanner;
/*
 * 1. Write a Java program that uses polymorphism by defining an interface called Shape
	with methods to calculate the area and perimeter of a shape. Then create classes
	that implement the Shape interface for different types of shapes, such as circles and
	triangles.
 * 
*/
public class MainPolymorphism {

	public static void main(String[] args) {
		
		//calculating the area and perimeter of shapes
		Scanner scan = new Scanner(System.in);
		
		Shape t = new Triangle();
		Shape c = new Circle();
		Shape r = new Rectangle();
		Shape sq = new Square();
		
		t.input();
		t.getArea();
		t.getPerimeter();

		c.input();
		c.getArea();
		c.getPerimeter();
			
		r.input();
		r.getArea();
		r.getPerimeter();
		
		sq.input();
		sq.getArea();
		sq.getPerimeter();
	}

}

/** output:
 * 
Please enter the base of triangle:
10
Please enter the height of triangle:
12
The area of the triangle is 60.0
The perimeter of the triangle is 37.62049935181331

Please enter the radius of circle:
5
The area of the circle is 78.5
The perimeter of the circle is 31.400000000000002

Please enter the legnth of rectangle
10
Please enter the breadth of rectangle
5
The area of the rectangle is 50.0
The perimeter of the rectangle is 30.0

Please enter the legnth of square
12
The area of the square is 144.0
The perimeter of the square is 48.0
 */


