package com.test.assignment;

import java.util.Scanner;

public class Circle implements Shape {

	private double radius;
	private double pi=3.14;

	
	public Circle () {
		
	}
	
	public Circle(double radius) {
		this.radius = radius;
	}
	
	@Override
	public double getArea() {
		//System.out.println("Math.PI:"+Math.PI);
		return pi*radius*radius;
	}

	@Override
	public double getPerimeter() {
		return 2 * pi * radius;
	}

	@Override
	public void input() {
		Scanner scan = new Scanner(System.in);
		System.out.println("\nPlease enter the radius of circle:");
		double radius = scan.nextDouble();
		Shape c = new Circle(radius);
		
		System.out.println("The area of the circle is " + c.getArea());
	    System.out.println("The perimeter of the circle is " + c.getPerimeter());
	}
	
}
