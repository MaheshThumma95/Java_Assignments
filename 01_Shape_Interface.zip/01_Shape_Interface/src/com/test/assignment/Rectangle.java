package com.test.assignment;

import java.util.Scanner;

public class Rectangle implements Shape {

	private double length;
	private double breadth;

	public Rectangle(double length, double breadth) {
		this.length = length;
		this.breadth = breadth;
	}


	public Rectangle() {
		
	}


	@Override
	public double getArea() {
	
		return length * breadth;
	}

	@Override
	public double getPerimeter() {
	
		return 2*(length + breadth);
	}

	@Override
	public void input() {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("\nPlease enter the legnth of rectangle");
		double length = scan.nextDouble();
		
		System.out.println("Please enter the breadth of rectangle");
		double breadth = scan.nextDouble();
		
		Shape r = new Rectangle(length,breadth);
		System.out.println("The area of the rectangle is " + r.getArea());
	    System.out.println("The perimeter of the rectangle is " + r.getPerimeter());
	}

	
}
