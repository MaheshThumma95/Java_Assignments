package com.test.persistence;

import com.test.dto.Student;

public interface IStudentDao {

		// CRUD Operations to implemented
		//create student
		public String addStudent(String sname, Integer sage, String saddress);
		
		//read/find student details
		public Student searchStudent(Integer id);
	
		//update student
		public String updateStudent(Student student);
		
		//delete student
		public String deleteStudent(Integer sid);
		

}
