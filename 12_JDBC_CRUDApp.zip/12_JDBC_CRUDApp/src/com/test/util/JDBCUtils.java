package com.test.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class JDBCUtils {
	
	private JDBCUtils() {
		
	}
	
	
	static {
		//Step1:loading the register the Driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection()throws SQLException, IOException{
	
		//Step:3. Establish the connection.
		HikariConfig config = new HikariConfig("src\\com\\test\\properties\\applicaton.properties");
		HikariDataSource dataSource = new HikariDataSource(config);

		return dataSource.getConnection();
	}

	
}
