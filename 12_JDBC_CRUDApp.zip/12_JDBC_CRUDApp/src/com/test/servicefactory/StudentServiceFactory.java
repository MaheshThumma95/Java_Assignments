package com.test.servicefactory;

import com.test.service.IStudentService;
import com.test.service.StudentServiceImpl;

//Abstraction logic of implementation
public class StudentServiceFactory {
	
	private static IStudentService studentService = null;
	
	//make constructor private to avoid object creation
	private StudentServiceFactory() {
		
	}
	
	public static IStudentService getStudentService() {
		//singleton pattern code
		if(studentService == null) {
			studentService = new StudentServiceImpl();	
		}
		return studentService;
	}
}
